# -*- coding: utf-8 -*-

from . import res_partner
from . import res_company
from . import mail_template
from . import product
from . import account
from . import sale_order
from . import res_country
from . import tusdatos_api
from . import sale_subscription
from . import ir_sequence
from . import payu_latam_api
from . import http
from . import website
